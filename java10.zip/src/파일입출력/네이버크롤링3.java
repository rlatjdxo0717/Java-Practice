package ���������;

import java.io.FileWriter;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class ���̹�ũ�Ѹ�3 {

	public static void main(String[] args) throws Exception {
		String[] code = { "005360", "005930", "068270" };
		String[] company = { "�𳪹�", "�Ｚ����", "��Ʈ����" };

		for (int i = 0; i < company.length; i++) {
			Document doc = Jsoup.connect("https://finance.naver.com/item/main.nhn?code=" + code[i]).get();
//			System.out.println(doc);
			Elements elist = doc.select("span.blind");
//			System.out.println(elist);
			System.out.println(company[i]);
			System.out.println("-----------");
			
			String today = elist.get(12).text();
			System.out.println("����: " + today);
			String yesterday = elist.get(15).text();
			System.out.println("����: " + yesterday);
			String high = elist.get(16).text();
			System.out.println("����: " + high);
			System.out.println();
			
			Elements elist2 = doc.select("div.wrap_company h2 a");
			System.out.println(elist2.get(0).text());
		}

	}
}
