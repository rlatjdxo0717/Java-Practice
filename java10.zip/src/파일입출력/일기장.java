package ���������;

import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class �ϱ��� {
	private JTextField t1;
	private JTextField t2;

	public �ϱ���() {
		JFrame f = new JFrame("���� �ϱ��� �ۼ�ȭ��");
		f.getContentPane().setBackground(Color.ORANGE);
		f.setSize(465, 509);
		f.getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel lblNewLabel = new JLabel("\uB0A0 \uC9DC");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 30));
		f.getContentPane().add(lblNewLabel);
		
		t1 = new JTextField();
		t1.setBackground(new Color(0, 255, 255));
		t1.setFont(new Font("����", Font.BOLD, 30));
		f.getContentPane().add(t1);
		t1.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\uC81C \uBAA9");
		lblNewLabel_1.setFont(new Font("����", Font.BOLD, 30));
		f.getContentPane().add(lblNewLabel_1);
		
		t2 = new JTextField();
		t2.setBackground(new Color(0, 255, 255));
		t2.setFont(new Font("����", Font.BOLD, 30));
		f.getContentPane().add(t2);
		t2.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("\uC624\uB298\uC758 \uC77C\uAE30 \uC791\uC131");
		lblNewLabel_2.setFont(new Font("����", Font.BOLD, 30));
		f.getContentPane().add(lblNewLabel_2);
		
		JTextArea t3 = new JTextArea();
		t3.setBackground(new Color(0, 255, 255));
		t3.setFont(new Font("Monospaced", Font.BOLD, 30));
		t3.setColumns(20);
		t3.setRows(5);
		f.getContentPane().add(t3);
		
		JButton b = new JButton("\uD30C\uC77C\uC5D0 \uC77C\uAE30 \uC800\uC7A5");
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//1. ��¥�� �����ٰ� �����̸��� ������ �Ѵ�.
				String date = t1.getText();
				try {
					FileWriter file 
					     = new FileWriter(date + ".txt");
					//2. ���Ͽ� ��¥, ����, ������ ����
					String s2 = t2.getText();
					String s3 = t3.getText();
					
					file.write(date + "\n");
					file.write(s2 + "\n");
					file.write(s3 + "\n");
					//3. ���� ��Ʈ���� �ݾƾ� �Ѵ�.
					file.close();
					JOptionPane.showMessageDialog(null, "���� ���� ����.");
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		b.setBackground(Color.GREEN);
		b.setFont(new Font("����", Font.BOLD, 30));
		f.getContentPane().add(b);
		f.setVisible(true);
	}
	
	public static void main(String[] args) {
		�ϱ��� name = new �ϱ���();
	}

}
