package ���������;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class �ϱ���α��� {
	private JTextField t1;
	private JTextField t2;
	public �ϱ���α���() {
		JFrame f = new JFrame("���� �ϱ���");
		f.getContentPane().setBackground(Color.PINK);
		f.setSize(495, 527);
		f.getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("D:\\aliciawill\\day07\\004.png"));
		f.getContentPane().add(label);
		
		JLabel lblNewLabel = new JLabel("ID\uC785\uB825");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 20));
		f.getContentPane().add(lblNewLabel);
		
		t1 = new JTextField();
		t1.setBackground(Color.YELLOW);
		t1.setFont(new Font("����", Font.BOLD, 15));
		f.getContentPane().add(t1);
		t1.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("PW\uC785\uB825");
		lblNewLabel_1.setFont(new Font("����", Font.BOLD, 20));
		f.getContentPane().add(lblNewLabel_1);
		
		t2 = new JTextField();
		t2.setBackground(Color.YELLOW);
		t2.setFont(new Font("����", Font.BOLD, 15));
		f.getContentPane().add(t2);
		t2.setColumns(10);
		
		JButton btnNewButton = new JButton("\uB85C\uADF8\uC778\uCC98\uB9AC");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s1 = t1.getText(); //�Է���id
				String s2 = t2.getText(); //�Է���pw
				System.out.println("�Է�id " + s1);
				System.out.println("�Է�pw " + s2);
				
				String id = "root";
				String pw = "1234";
				
				if (id.equals(s1) && pw.equals(s2)) {
					System.out.println("�α���ok");
					�ϱ��� diary = new �ϱ���();
					
				} else {
					System.out.println("�α���not");
					JOptionPane.showMessageDialog(null, "�ٽ� �α������ּ���.");
					t1.setText("");
					t2.setText("");
				}
				
			}
		});
		btnNewButton.setBackground(Color.GREEN);
		btnNewButton.setFont(new Font("����", Font.BOLD, 50));
		f.getContentPane().add(btnNewButton);
		f.setVisible(true);
	}
	public static void main(String[] args) {
		�ϱ���α��� name = new �ϱ���α���();
	}

}
