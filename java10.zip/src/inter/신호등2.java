package inter;

import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;

public class ��ȣ��2 extends JFrame{

	public ��ȣ��2() {
		getContentPane().setBackground(Color.BLACK);
		setTitle("��ȣ��2");
		setSize(301, 292);
		getContentPane().setLayout(new FlowLayout());
		
		JButton red = new JButton("\uBE68\uAC15\uC2E0\uD638");
		red.setFont(new Font("����", Font.BOLD, 57));
		red.setBackground(Color.RED);
		getContentPane().add(red);
		
		JButton yellow = new JButton("\uB178\uB791\uC2E0\uD638");
		yellow.setFont(new Font("����", Font.BOLD, 57));
		yellow.setBackground(Color.YELLOW);
		getContentPane().add(yellow);
		
		JButton blue = new JButton("\uD30C\uB791\uC2E0\uD638");
		blue.setFont(new Font("����", Font.BOLD, 57));
		blue.setBackground(Color.BLUE);
		getContentPane().add(blue);
		
		���ó���� all = new ���ó����();
		red.addActionListener(all);
		yellow.addActionListener(all);
		blue.addActionListener(all);
		
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
		��ȣ��2 name = new ��ȣ��2();
	}

}
