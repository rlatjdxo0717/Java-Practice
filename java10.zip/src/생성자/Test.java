package ������;

public class Test {

	public static void main(String[] args) {
		int i = 100;
		String s = String.valueOf(i);
		System.out.println(s + 200);
	}

}
